// Copyright(c) 2015-present, Gabi Melman & spdlog contributors.
// Distributed under the MIT License (http://opensource.org/licenses/MIT)

#pragma once

#include <spdlog/common.h>
#include <unordered_map>

SPDLOG_NAMESPACE_BEGIN
namespace cfg {
namespace helpers {
//
// Init levels from given string
//
// Examples:
//
// set global level to debug: "debug"
// turn off all logging except for logger1: "off,logger1=debug"
// turn off all logging except for logger1 and logger2: "off,logger1=debug,logger2=info"
//
SPDLOG_API void load_levels(const std::string &levels_spec);
}  // namespace helpers

}  // namespace cfg
SPDLOG_NAMESPACE_END

#ifdef SPDLOG_HEADER_ONLY
#include "helpers-inl.h"
#endif  // SPDLOG_HEADER_ONLY
